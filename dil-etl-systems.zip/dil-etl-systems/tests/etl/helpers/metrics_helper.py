import pandas as pd
import math
import os
from modules.utilities.aws.rds.query.model_helper import get_table_name_from_model
from modules.utilities.generic.df_cleaner import to_snake_case
from modules.utilities.generic.os_helper import get_output_path


def get_db_metrics(test_config, db_record):

    db_metrics = get_all_relevant_metrics(test_config, db_record)
    metric_dic = get_metric_dictionary(test_config)
    metrics = list(map(lambda db_metric:
                       {
                           'metric_type_name': db_metric.MetricType.MetricTypeName,
                           'metric_dataset_name': get_metric_dataset_name(db_metric, metric_dic),
                           'value': db_metric.Value
                       },
                       db_metrics))

    return metrics


def get_all_relevant_metrics(test_config, db_record):
    cont_metrics = get_metrics_by_type(
        test_config, db_record, 'continuous_metrics')
    cat_metrics = get_metrics_by_type(
        test_config, db_record, 'categorical_metrics')

    db_metrics = cont_metrics + cat_metrics
    db_metrics_filtered = [
        i for i in db_metrics if i.MetricType.MetricTypeName not in test_config['manual_cols']]

    return db_metrics_filtered


def get_metrics_by_type(test_config, db_record, metrics_type_str):
    metrics_type_model = test_config['relationships'][metrics_type_str]
    if metrics_type_model == None:
        return []
    else:
        table_name = get_table_name_from_model(metrics_type_model)
        try:
            metrics_unfiltered = getattr(db_record, table_name)
        except:
            metrics_unfiltered = getattr(db_record, table_name + "s")

    metrics_filtered = list(filter(lambda metric: get_project_metrics_only(
        metric, test_config['project_type_id']), metrics_unfiltered))
    return metrics_filtered


def get_project_metrics_only(metric, project_type_id):
    all_project_type_ids = list(
        map(lambda x: x.ProjectTypeId, metric.MetricType.ProjectMetricAssignments))
    return project_type_id in all_project_type_ids


def get_metric_dictionary(test_config):
    df_raw = pd.read_csv(get_output_path() + "types/metric_type_names.csv")
    if os.name == "nt":
        df_raw = pd.read_csv(get_output_path() + "types\\metric_type_names.csv")
    df_filtered = df_raw[~df_raw['RawName'].isin(test_config['manual_cols'])]
    return df_filtered


def get_metric_dataset_name(metric, metric_dic):
    default_name = to_snake_case(metric.MetricType.MetricTypeName)
    if metric.MetricType.MetricDisplayName not in metric_dic['MetricDisplayName'].tolist():
        return default_name
    else:
        matches = metric_dic.loc[
            metric_dic['MetricDisplayName'] == metric.MetricType.MetricDisplayName
        ]

        if len(matches) == 1:
            return matches['RawName'].values[0]
        else:
            return default_name


def get_metric_errors(test_config, raw_row, db_record, pk_id):
    errors = []
    db_metrics = get_db_metrics(test_config, db_record)
    for db_metric in db_metrics:
        try:
            raw_value = raw_row[db_metric['metric_dataset_name']]
            raw_value_rounded = round(raw_value*10000)/10000
            assert raw_value_rounded == db_metric['value']

        except AssertionError:
            errors.append({
                'record_id': pk_id,
                'dataset_name': db_metric['metric_dataset_name'],
                'db_value': db_metric['value'],
                'raw_value': raw_value,
            })

    return errors
