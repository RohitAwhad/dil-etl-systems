from modules.utilities.aws.rds.tables.health_system import HealthSystem
from modules.utilities.aws.rds.tables.assignments.health_system_categorical_metric import HealthSystemCategoricalMetricAssignment
from modules.utilities.aws.rds.tables.assignments.health_system_continuous_metric import HealthSystemContinuousMetricAssignment

from modules.utilities.aws.rds.tables.hospital import Hospital
from modules.utilities.aws.rds.tables.assignments.hospital_categorical_metric_assignment import HospitalCategoricalMetricAssignment
from modules.utilities.aws.rds.tables.assignments.hospital_continuous_metric_assignment import HospitalContinuousMetricAssignment

from modules.utilities.aws.rds.tables.types.state_type import StateType
from modules.utilities.aws.rds.tables.assignments.state_type_continuous_metric_assignment import StateTypeContinuousMetricAssignment

test_configs = {
    'systems': {
        'health_system': {
            'project_type_id': 2,
            'main_model': HealthSystem,
            'file_name': 'dat_health_system_final',
            'key_cols': [
                {'raw': 'health_sys_id', 'db': 'Hsi'},
            ],
            'relationships': {
                'continuous_metrics': HealthSystemContinuousMetricAssignment,
                'categorical_metrics': HealthSystemCategoricalMetricAssignment
            },
            'manual_cols': ['SysMaPlanContracts']
        },

        'hospital': {
            'project_type_id': 2,
            'main_model': Hospital,
            'file_name': 'dat_hospital_final',
            'key_cols': [
                {'raw': 'ccn', 'db': 'CcnId'},
                {'raw': 'compendium_hospital_id', 'db': 'CompendiumId'},
            ],
            'relationships': {
                'continuous_metrics': HospitalContinuousMetricAssignment,
                'categorical_metrics': HospitalCategoricalMetricAssignment
            },
            'manual_cols': []
        },

        'state': {
            'project_type_id': 2,
            'main_model': StateType,
            'file_name': 'dat_state_final',
            'key_cols': [
                {'raw': 'state', 'db': 'StateAbbreviation'},
            ],
            'relationships': {
                'continuous_metrics': StateTypeContinuousMetricAssignment,
                'categorical_metrics': None,
            },
            'manual_cols': ['DbSample', 'IsRural']
        },

    }
}
