import sqlalchemy.ext.declarative as sqld

sqla_base = sqld.declarative_base()