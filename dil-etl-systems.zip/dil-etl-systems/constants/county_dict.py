
county_type_dict = {
    8: {
        "broomfield": "Boulder"  
    },
    22: {
        "adams": "Concordia Parish",
        "lasalle": "La Salle Parish",
    },
    39: {
        "ohio": "Belmont",
    },
    46: {
        'oglala lakota': 'Shannon',
    },
    51: {
        "emporia": "Greensville",
        "lexington": "Rockbridge",
        "martinsville": "Henry",
    }
}